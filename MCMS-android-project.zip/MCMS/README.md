# MCMS (MC MOD SHARE) – Android WebView app
Membuka https://mcmodshared.page.gd. minSdk 21 (Android 5+). Tanpa library native → satu APK jalan di HP 32-bit (armeabi-v7a) & 64-bit (arm64-v8a).

## Cara 1 – Android Studio
Open folder ini → tunggu Sync → Build ▸ Build APK(s) → `app/build/outputs/apk/debug/MCMS-debug.apk`.

## Cara 2 – Dari HP (tanpa Android Studio)
Buat repo GitHub → upload isi folder ini (termasuk `.github`) → tab Actions ▸ "Build MCMS APK" ▸ Run workflow → unduh artifact `MCMS-apk`.

## Catatan
- Untuk rilis Play Store: Build ▸ Generate Signed Bundle/APK (buat keystore sendiri, simpan baik-baik).
- Ganti URL di `MainActivity.kt` (konstanta `HOST`) kalau domain berubah.
