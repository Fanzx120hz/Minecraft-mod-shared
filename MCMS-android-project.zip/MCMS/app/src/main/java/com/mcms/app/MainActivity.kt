package com.mcms.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {
    companion object {
        const val HOST = "mcmodshared.page.gd"
        const val HOME = "https://$HOST/"
    }

    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var bar: ProgressBar
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingDownload: (() -> Unit)? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }
    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val p = pendingDownload; pendingDownload = null
        if (ok) p?.invoke() else Toast.makeText(this, R.string.need_storage, Toast.LENGTH_LONG).show()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun isOurHost(u: Uri?) = u?.host.let { it == HOST || (it != null && it.endsWith(".$HOST")) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#EAD9B6")
        window.navigationBarColor = Color.parseColor("#EAD9B6")
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true
        }

        web = WebView(this)
        swipe = SwipeRefreshLayout(this).apply {
            addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            setColorSchemeColors(Color.parseColor("#2A2230"))
            setProgressBackgroundColorSchemeColor(Color.parseColor("#7CCF5A"))
            setOnRefreshListener { web.reload() }
            setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
            progressTintList = ColorStateList.valueOf(Color.parseColor("#2A2230"))
        }
        val root = FrameLayout(this)
        root.addView(swipe, FrameLayout.LayoutParams(-1, -1))
        root.addView(bar, FrameLayout.LayoutParams(-1, dp(4)))
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            userAgentString = userAgentString + " MCMS-App/1.0"
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if ((u.scheme == "https" || u.scheme == "http") && isOurHost(u)) return false
                openExternal(u); return true
            }
            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) { swipe.isRefreshing = false }
            override fun onPageFinished(v: WebView, url: String?) { swipe.isRefreshing = false; CookieManager.getInstance().flush() }
            override fun onReceivedError(v: WebView, req: WebResourceRequest, err: WebResourceError) {
                if (req.isForMainFrame) showOffline(req.url.toString())
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                bar.progress = p; bar.visibility = if (p in 1..99) View.VISIBLE else View.GONE
            }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                try { picker.launch(params.createIntent()) }
                catch (e: Exception) { fileCb = null; cb.onReceiveValue(null) }
                return true
            }
            override fun onJsAlert(v: WebView, url: String?, msg: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setTitle(R.string.app_name).setMessage(msg)
                    .setPositiveButton(android.R.string.ok) { _, _ -> r.confirm() }.setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsConfirm(v: WebView, url: String?, msg: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setTitle(R.string.app_name).setMessage(msg)
                    .setPositiveButton(android.R.string.ok) { _, _ -> r.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> r.cancel() }.setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsPrompt(v: WebView, url: String?, msg: String?, def: String?, r: JsPromptResult): Boolean {
                val input = EditText(this@MainActivity).apply { setText(def) }
                AlertDialog.Builder(this@MainActivity).setTitle(R.string.app_name).setMessage(msg).setView(input)
                    .setPositiveButton(android.R.string.ok) { _, _ -> r.confirm(input.text.toString()) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> r.cancel() }.setOnCancelListener { r.cancel() }.show()
                return true
            }
        }
        web.setDownloadListener { url, ua, cd, mime, _ -> download(url, ua, cd, mime) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(startUrl(intent))
    }

    private fun startUrl(i: Intent?): String = i?.data?.takeIf { isOurHost(it) }?.toString() ?: HOME

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent)
        if (intent.data != null) web.loadUrl(startUrl(intent))
    }

    private fun openExternal(u: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: ActivityNotFoundException) { }
    }

    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        val go: () -> Unit = {
            try {
                val name = URLUtil.guessFileName(url, cd, mime)
                val r = DownloadManager.Request(Uri.parse(url)).setTitle(name)
                    .setDescription(getString(R.string.app_name))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                if (!mime.isNullOrEmpty()) r.setMimeType(mime)
                CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
                if (!ua.isNullOrEmpty()) r.addRequestHeader("User-Agent", ua)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
                Toast.makeText(this, getString(R.string.downloading, name), Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { openExternal(Uri.parse(url)) }
        }
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDownload = go; storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else go()
    }

    private fun showOffline(retry: String) {
        val html = """<html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;display:flex;min-height:100vh;align-items:center;justify-content:center;background:#ead9b6;font-family:sans-serif;color:#2a2230;text-align:center">
<div style="padding:28px;margin:20px;background:#fffaf0;border:3px solid #2a2230;border-radius:16px;box-shadow:5px 5px 0 #2a2230">
<h2 style="margin:0 0 8px">MC MOD SHARE</h2><p>Tidak ada koneksi.<br>No connection.</p>
<a href="$retry" style="display:inline-block;margin-top:8px;padding:10px 22px;background:#7ccf5a;color:#2a2230;font-weight:bold;text-decoration:none;border:3px solid #2a2230;border-radius:12px">Coba lagi / Retry</a>
</div></body></html>"""
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); web.saveState(outState) }
    override fun onPause() { super.onPause(); web.onPause(); CookieManager.getInstance().flush() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { fileCb?.onReceiveValue(null); web.destroy(); super.onDestroy() }
}
